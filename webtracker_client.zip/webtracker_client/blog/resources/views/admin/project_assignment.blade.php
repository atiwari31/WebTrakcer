@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header" style="text-align: center;"><b>Project Assignment</b></div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    <form method="post" action="{{url('/save-project-assignment')}}">@csrf
                        <div class="form-row">
                            <div class="form-group col-md-4">
                            <label for="inputEmail4"><b>Projects</b></label>
                            <select name="project" id="sel_project" class="form-control">
                                <option disabled selected>Select Project</option>
                                @foreach($projects as $p)
                               <option value="{{$p->id}}">{{$p->project}}</option> 
                               @endforeach
                            </select>
                             @error('project')
                                <span class="text-danger" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror 
                            </div>
                            <div class="form-group col-md-4">
                            <label for="inputPassword4"><b>Task</b></label>
                            <select name="task_id" id="sel_task" class="form-control">
                            <option disabled selected>Select Task</option>
                            
                            </select>
                             @error('task_id')
                                <span class="text-danger" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                            </div>
                            <div class="form-group col-md-4">
                            <label for="inputPassword4"><b>User</b></label>
                            <select name="user_id" id="sel_project" class="form-control">
                                <option disabled selected>Select User</option>
                                @foreach($users as $user)
                               <option value="{{$user->id}}">{{$user->name}}</option> 
                               @endforeach
                            </select>
                             @error('user_id')
                                <span class="text-danger" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Assign</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-12">
            <div class="card">
                <div class="card-header" style="text-align: center;"><b>Project Assignment Details</b></div>

                <div class="card-body">
                    
                    <table class="table">
                        <thead>
                            <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Project</th>
                            <th scope="col">Task</th>
                            <th scope="col">User</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($projectAssignments as $projectAssignment)
                            <tr>
                            <th scope="row">{{$projectAssignment->project_id}}</th>
                            <td>{{$projectAssignment->project}}</td>
                            <td>{{$projectAssignment->task}}</td>
                            <td>{{$projectAssignment->name}}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@section('page_js')
<!-- Script -->
<script type='text/javascript'>

$(document).ready(function(){

  // Project Change
  $('#sel_project').change(function(){

     // Project id
     var id = $(this).val();

    // alert('hi' + id);

     // Empty the dropdown
    //  $('#sel_task').find('option').not(':first').remove();
     $('#sel_task').find('option').remove();

     // AJAX request 
     $.ajax({
       url: 'getTask/'+id,
       type: 'get',
       dataType: 'json',
       success: function(response){

        console.log(response);

         var len = 0;
         if(response['data'] != null){
           len = response['data'].length;
         }

         if(len > 0){
           // Read data and create <option >
           for(var i=0; i<len; i++){

             var id = response['data'][i].id;
             var task = response['data'][i].task;

             var option = "<option value='"+id+"'>"+task+"</option>"; 

             $("#sel_task").append(option); 
           }
         }

       }
    });
  });

});

</script>

@endsection
