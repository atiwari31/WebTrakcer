@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header" style="text-align: center;"><b>Project Creation</b></div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    <form method="post" action="{{url('/save-project-creation')}}">@csrf
                        <div class="form-row">
                            <div class="form-group col-md-4">
                            <label for="inputEmail4"><b>Projects</b></label>
                            <select name="project" id="sel_project" class="form-control">
                                <option disabled selected>Select Project</option>
                                @foreach($projects as $p)
                               <option value="{{$p->id}}">{{$p->project}}</option> 
                               @endforeach
                            </select>
                            </div>
                            <div class="form-group col-md-4">
                            <label for="inputPassword4"><b>Task</b></label>
                            <input type="text" name="task" class="form-control">
                            </div>
                            <div class="form-group col-md-4">
                            <label for="inputPassword4"><b>Cost Per Hours</b></label>
                            <input type="text" name="working_per_hours" class="form-control">
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-12">
            <div class="card">
                <div class="card-header" style="text-align: center;"><b>Project Creation Details</b></div>

                <div class="card-body">
                    
                    <table class="table">
                        <thead>
                            <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Project</th>
                            <th scope="col">Task</th>
                            <th scope="col">Cost Per Hours</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($projectCreations as $projectCreation)
                            <tr>
                            <th scope="row">{{$projectCreation->project_id}}</th>
                            <td>{{$projectCreation->project}}</td>
                            <td>{{$projectCreation->task}}</td>
                            <td>{{$projectCreation->working_per_hours}}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
