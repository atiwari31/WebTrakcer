@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header" style="text-align: center;"><b>User Working Report</b></div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    <table class="table">
                      <thead>
                        <tr>
                          <th scope="col">Name</th>
                          <th scope="col">Email</th>
                          <th scope="col">Start Time</th>
                          <th scope="col">Duration</th>
                          <th scope="col">End Time</th>
                          <th scope="col">Working Hours</th>
                          <th scope="col">Billing</th>
                          <th scope="col">System Activity</th>
                        </tr>
                      </thead>
                      <tbody>
                        @foreach($users as $user)

                        @php
                        $time = $user->duration;
       
                        $pieces = explode(":", $time);

                        $int = (int)$pieces[0];

                        $billing = $user->working_per_hours * $int;
                        @endphp

                        <tr>
                          <th scope="row">{{$user->name}}</th>
                          <td>{{$user->email}}</td>
                          <td>{{$user->start_time}}</td>
                          @if(!empty($user->duration))
                          <td>{{$user->duration}}</td>
                          @else
                          <td>--</td>
                          @endif
                          @if(!empty($user->end_time))
                          <td>{{$user->end_time}}</td>
                          @else
                          <td>--</td>
                          @endif
                          @if(!empty($user->working_per_hours))
                          <td>{{$user->working_per_hours}}</td>
                          @else
                          <td>--</td>
                          @endif
                          <td>{{$billing}}</td>
                          <td>
                              <a href="{{url('/user-event/'.$user->userid)}}">Report</a>
                          </td>
                        </tr>
                        @endforeach
                      </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
