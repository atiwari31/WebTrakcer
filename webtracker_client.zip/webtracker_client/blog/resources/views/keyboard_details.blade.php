@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Project') }}</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    <table class="table">
                        <thead>
                            <tr>
                            <th scope="col">id</th>
                            <th scope="col">keyboard_mouse_event_id</th>
                            <th scope="col">description</th>
                            <th scope="col">start_time</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($Keyboards as $k)
                            <tr>
                            <th scope="row">{{$k->id}}</th>
                            <td>{{$k->keyboard_mouse_event_id}}</td>
                            <td>{{$k->description}}</td>
                            <td>{{$k->start_time}}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

