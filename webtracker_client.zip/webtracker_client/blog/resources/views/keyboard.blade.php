<p>This page turns violet when you hold the V key.</p>

<script>
  addEventListener("keydown", function(event) {
    if (event.keyCode == 32)
      //document.body.style.background = "violet";
      eventHandleFun(32,"Space");
  });
  addEventListener("keyup", function(event) {
    if (event.keyCode == 8)
      //document.body.style.background = "green";
      eventHandleFun(8,"Backpace");
  });
    addEventListener("keyup", function(event) {
    if (event.keyCode == 13)
      //document.body.style.background = "green";
      eventHandleFun(13,"Enter");
  });
  addEventListener("keyup", function(event) {
    if (event.keyCode == 16)
      //document.body.style.background = "green";
      eventHandleFun(16,"Shift");
  });
  addEventListener("keyup", function(event) {
    if (event.keyCode == 17)
      //document.body.style.background = "green";
      eventHandleFun(17,"Ctrl");
  });
  addEventListener("keyup", function(event) {
    if (event.keyCode == 18)
      //document.body.style.background = "green";
      eventHandleFun(18,"Alt");
  });
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>


<script>

  function eventHandleFun(keyCode,description){
alert("hi");
    var dataString = 'keyCode='+keyCode+'&description='+description;
       
  $.ajax({
    type:"POST",
    //data:dataString,
   // _token:"{{csrf_token()}}",
    data: { "_token": "{{ csrf_token() }}", "keyCode": keyCode,"description":description},
    url:'/saveKeyboardDetail',
    success:function(data) {
      alert(data);
    }
  });

  
  

  }

</script>