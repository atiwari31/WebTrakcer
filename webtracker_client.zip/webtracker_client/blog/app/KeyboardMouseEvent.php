<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class KeyboardMouseEvent extends Model
{
    //
}
