<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Carbon\Carbon; 
use App\Time;
use DB;
use App\Project;
use App\Task;
use Auth;

class TimeController extends Controller
{
    public function time()
    {
        return view('time');
    }

    public function saveStartTime()
    {
        // echo "start";
        $start = Carbon::now();
        // echo $start;die;
       
        $time = Time::updateOrCreate(
            ['user_id' =>  Auth::id()],
            ['start_time' => $start]
        );

        return redirect('/project');
        
    }

    public function saveEndTime()
    {
        $end = Carbon::now();
        
        $time = Time::updateOrCreate(
            ['user_id' =>  Auth::id()],
            ['end_time' => $end]
        );

        $userTimeData = Time::where(['user_id'=>Auth::id()])->first();

        $start = Carbon::parse($userTimeData->start_time);
        $end = Carbon::parse($userTimeData->end_time);

        // $totalDuration =  $start->diff($end)->format('%H:%I:%S')." Minutes";
        $totalDuration =  $start->diff($end)->format('%H:%I:%S');
        
        $time = Time::where(['user_id'=>Auth::id()])->update(
            ['duration' => $totalDuration]
        );

        // return back();
        return response("done");
    }

    public function projectTask()
    {
        // $projects = Project::all();
        $projects = DB::table('project_assignments')
            ->where(['user_id' => Auth::id()])
            ->join('projects', 'project_assignments.project_id', '=', 'projects.id')
            ->select('project_assignments.*', 'projects.project', 'projects.id as project_id')
            ->get();

        $projectDetails = DB::table('user_project_task')
            ->where(['user_project_task.user_id' => Auth::id()])
            ->join('projects', 'user_project_task.project_id', '=', 'projects.id')
            ->join('project_creations', 'user_project_task.task_id', '=', 'project_creations.id')
            ->join('times', 'user_project_task.user_id', '=', 'times.user_id')
            ->select('user_project_task.*', 'user_project_task.id as project_id', 'projects.project', 'project_creations.task', 'times.end_time')
            ->get();
            // echo "<pre>"; print_r($projectDetails); die;
        return view('project_task', compact('projects', 'projectDetails'));
    }

    public function getTask($project_id = 0)
    {
        // $projects = Project::all();
        // $tasks = Task::where(['oject_id' pr=> $project_id])->get();
        // return view('project_task', compact('projects', 'tasks'));
        // return response()->json($tasks);

        // Fetch Task by Departmentid
        // $empData['data'] = Task::orderby("task","asc")
        // 			->select('id','task')
        // 			->where('project_id',$project_id)
        // 			->get();
        $empData['data'] = DB::table('project_creations')
                    ->select('id','task')
                    ->where('project_id',$project_id)
                    ->get();           
  
        return response()->json($empData);
    }

    // Fetch records
    public function getEmployees($departmentid=0){

    	// Fetch Employees by Departmentid
        $empData['data'] = Employees::orderby("name","asc")
        			->select('id','name')
        			->where('department',$departmentid)
        			->get();
  
        return response()->json($empData);
     
    }
}
