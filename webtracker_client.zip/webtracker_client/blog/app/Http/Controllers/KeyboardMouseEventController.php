<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Carbon\Carbon;
use DB;
use Auth;

class KeyboardMouseEventController extends Controller
{
    public function keyboard()
    {
        return view('keyboard');
    }

    public function saveKeyboardDetail(Request $request)
    {
        $event = 'Keypaid';

        if($request->description == 'Mouse')
        {
                $event = 'Mouse';
        }

        $start = Carbon::now();
        $save = DB::table('keyboard_mouse_event_details')->insert([
            'user_id' => Auth::id(),
            'keyboard_mouse_event_id' => $request->keyCode,
            'description' => $request->description,
            'start_time' => $start,
            'event_type' => $event,
        ]);
    }

    public function getKeyboardDetails()
    {
        $Keyboards = DB::table('keyboard_mouse_event_details')->get();
        return view('keyboard_details', compact('Keyboards'));
    }
}
