<?php

namespace App\Http\Controllers\Api;

use DB;
use App\User;
use Validator;
use App\Project;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Http;

class ApiController extends Controller
{

	public function authenticate(Request $request)
    {
		$validator = Validator::make($request->all(), [
			'email' => 'email'
		]);
		if ($validator->fails()) {
			$resp = [
				'code' => 409,
				'error' => $validator->errors(),
			];
			return response($resp);
		} else {

			$data = $request->all();
			// echo "<pre>"; print_r($data); die;

			$userDetails = User::where(['email'=>$data['email']])->first();

			if($userDetails) {
				// echo "<pre>"; print_r($userDetails); die;
				Auth::Login($userDetails);
				return view('home');

			} else {
				// echo "User Not Found"; die;
				
				// $endpoint = "http://65.0.2.180/api/getuserdetails";
				// $client = new \GuzzleHttp\Client();

				// $response = $client->request('POST', $endpoint, ['query' => [
				// 	'email' => $data['email']
				// ]]);

				// $statusCode = $response->getStatusCode();
				// $content = $response->getBody();

				// or when your server returns json
				// $content = json_decode($response->getBody(), true);

				// echo "<pre>"; print($statusCode);
				// echo "<pre>"; print($content);

				// echo $content;

				$response = Http::post('http://65.0.2.180/api/getuserdetails', [
					'email' => $data['email']
				]);

				$content = $response->body();
				// $content = $response->json();
				// $data = json_decode($response->body());
				// echo "<pre>"; print($content); 

				// return $content->getData()->success;

				// $WorkingArray = json_decode(json_encode($content),true);
				$arr = json_decode($content, true);
				// echo $arr["success"];
				// return $data[0]['success'];

				// echo "<pre>"; print_r($arr);

				$success 		= $arr["success"];

				if($success == 2){
					$userId  		= $arr["user"]["id"];
					$email  		= $arr["user"]["email"];
					$firstName   	= $arr["user"]["first_name"];
					$middleName   	= $arr["user"]["middle_name"];
					$lastName   	= $arr["user"]["last_name"];
					$userName   	= $arr["user"]["username"];
					$companyName   	= $arr["user"]["company_name"];
					$gender   		= $arr["user"]["gender"];
					$dob   			= $arr["user"]["dob"];
		
					// for Name
					$name = $firstName;
					if($middleName){
						$name = $name.' '.$middleName;
					}
					if($lastName){
						$name = $name.' '.$lastName;
					}
					// return $name;
		
					// insert record in user_table
					$save = User::create([
						'name' 				=> $name,
						'email' 			=> $email,
						'role' 				=> 'USER',
						// 'password' => Hash::make($data['password']),
						'eiliana_user_id' 	=> $userId
					]);
		
					if($save){
						Auth::Login($save);
						// echo Auth::user()->name;
						// return redirect('/home'); 
						return view('home');
					} else {
						return redirect('/login');
					};
					
					// die;
				} else {
					return $content = $response->json();
				}
			}

		}
    }

	function users()
	{
		$users = DB::table('users')->where(['role' => 'USER'])->get();

		if ($users->count()) {
			return response()->json($data = [
				'status' => 200,
				'msg' => 'Success',
				'data' => $users
			]);
		} else {
			return response()->json($data = [
				'status' => 201,
				'msg' => 'Data Not Found'
			]);
		}
	}

	function keyboardMouseEventDetails()
	{
		$keyboard_mouse_event_details = DB::table('keyboard_mouse_event_details')->get();

		if ($keyboard_mouse_event_details->count()) {
			return response()->json($data = [
				'status' => 200,
				'msg' => 'Success',
				'data' => $keyboard_mouse_event_details
			]);
		} else {
			return response()->json($data = [
				'status' => 201,
				'msg' => 'Data Not Found'
			]);
		}
	}

	function addProject(Request $request)
	{
		$validator = Validator::make($request->all(), [
			'project' => 'required',
			'eiliana_project_id' => 'required',
			'eiliana_client_id' => 'required'
		]);
		if ($validator->fails()) {
			$resp = [
				'code' => 409,
				'error' => $validator->errors(),
			];
			return response($resp);
		} else {

			$saveProject = DB::table('projects')->insert([
				'project' => $request->project,
				'eiliana_project_id' => $request->eiliana_project_id,
				'eiliana_client_id' => $request->eiliana_client_id
			]);

			if ($saveProject) {
				return response()->json($data = [
					'status' => 200,
					'msg' => 'Saved!!',
				]);
			} else {
				return response()->json($data = [
					'status' => 203,
					'msg' => 'something went wrong'
				]);
			}
		}
	}

	function projects()
	{
		// echo "Rekha";

		$projects = DB::table('projects')->get();

		if ($projects->count()) {
			return response()->json($data = [
				'status' => 200,
				'msg' => 'Success',
				'data' => $projects
			]);
		} else {
			return response()->json($data = [
				'status' => 201,
				'msg' => 'Data Not Found'
			]);
		}
	}

	public function projectCreation(Request $request)
	{

		$validator = Validator::make($request->all(), [
			'project' => 'required',
			'task' => 'required',
			'working_per_hours' => 'required',
			'eiliana_module_id' => 'required',
		]);
		if ($validator->fails()) {
			$resp = [
				'code' => 409,
				'error' => $validator->errors(),
			];
			return response($resp);
		} else {

			$saveProject = DB::table('project_creations')->insert([
				'project_id' => $request->project,
				'task' => $request->task,
				'working_per_hours' => $request->working_per_hours,
				'eiliana_module_id' => $request->eiliana_module_id,
			]);

			if ($saveProject) {
				return response()->json($data = [
					'status' => 200,
					'msg' => 'Saved!!',
				]);
			} else {
				return response()->json($data = [
					'status' => 203,
					'msg' => 'something went wrong'
				]);
			}
		}
	}

	function projectCreationList()
	{
		$projectCreations = DB::table('project_creations')
			->join('projects', 'project_creations.project_id', '=', 'projects.id')
			->select('project_creations.*', 'project_creations.id as project_id', 'projects.*')
			->get();

		if ($projectCreations->count()) {
			return response()->json($data = [
				'status' => 200,
				'msg' => 'Success',
				'data' => $projectCreations
			]);
		} else {
			return response()->json($data = [
				'status' => 201,
				'msg' => 'Data Not Found'
			]);
		}
	}

	public function projectAssignment(Request $request)
	{

		$validator = Validator::make($request->all(), [
			'project' => 'required',
			'task_id' => 'required|unique:project_assignments',
			'user_id' => 'required',
			'eiliana_project_id' => 'required',
			'freelancer_id' => 'required',
		]);
		if ($validator->fails()) {
			$resp = [
				'code' => 409,
				'error' => $validator->errors(),
			];
			return response($resp);
		} else {

			$saveProject = DB::table('project_assignments')->insert([
				'project_id' => $request->project,
				'task_id' => $request->task_id,
				'user_id' => $request->user_id,
				'eiliana_project_id' => $request->eiliana_project_id,
				'freelancer_id' => $request->freelancer_id,
			]);

			if ($saveProject) {
				return response()->json($data = [
					'status' => 200,
					'msg' => 'Saved!!',
				]);
			} else {
				return response()->json($data = [
					'status' => 203,
					'msg' => 'something went wrong'
				]);
			}
		}
	}

	function projectAssignmentList()
	{
		$projectAssignments = DB::table('project_assignments')
			->join('projects', 'project_assignments.project_id', '=', 'projects.id')
			->join('project_creations', 'project_assignments.task_id', '=', 'project_creations.id')
			->join('users', 'project_assignments.user_id', '=', 'users.id')
			->select('users.*', 'projects.*', 'project_creations.*', 'project_assignments.id as project_id')
			->get();

		if ($projectAssignments->count()) {
			return response()->json($data = [
				'status' => 200,
				'msg' => 'Success',
				'data' => $projectAssignments
			]);
		} else {
			return response()->json($data = [
				'status' => 201,
				'msg' => 'Data Not Found'
			]);
		}
	}

	function userTimingReport()
	{
		$current_date = Carbon::now()->format('Y-m-d');

		$startTimeUser = DB::table('times')
			// ->join('project_assignments', 'times.user_id', '=', 'project_assignments.user_id')
			->whereBetween('times.start_time', [$current_date . ' 00:00:00', $current_date . ' 23:59:59'])->get();
		// echo "<pre>"; print_r($startTimeUser); die;

		$projectAssign = array();
		foreach ($startTimeUser as $assign) {
			$data = DB::table('project_assignments')->where(['user_id' => $assign->user_id])->first();
			if ($data) {
				$projectAssign[] = $data;
			}
		}
		// echo "<pre>"; print_r($projectAssign); die;

		$users = array();
		foreach ($projectAssign as $kk) {
			// echo $kk->user_id;
			$users[] = DB::table('users')
				->where(['role' => 'USER', 'users.id' => $kk->user_id])
				->join('project_assignments', 'users.id', '=', 'project_assignments.user_id')
				->join('project_creations', 'project_assignments.task_id', '=', 'project_creations.id')
				->join('times', 'users.id', '=', 'times.user_id')
				->select('users.id as userid', 'users.name', 'users.email', 'times.start_time', 'times.duration', 'times.end_time', 'project_assignments.project_id', 'project_assignments.task_id', 'project_creations.working_per_hours')
				->first();
			// echo "<pre>"; print_r($startTimeUser); die;
		}

		if ($users) {
			return response()->json($data = [
				'status' => 200,
				'msg' => 'Success',
				'data' => $users
			]);
		} else {
			return response()->json($data = [
				'status' => 201,
				'msg' => 'Data Not Found'
			]);
		}
	}

	function userProjectTask()
	{
		$user_project_task = DB::table('user_project_task')->get();

		if ($user_project_task->count()) {
			return response()->json($data = [
				'status' => 200,
				'msg' => 'Success',
				'data' => $user_project_task
			]);
		} else {
			return response()->json($data = [
				'status' => 201,
				'msg' => 'Data Not Found'
			]);
		}
	}

	function screenshots(Request $request){

		$validator = Validator::make($request->all(), [
			'userId'  => 'numeric',
			'date'    => 'date_format:Y-m-d'
		]);
		if ($validator->fails()) {
			$resp = [
				'code' => 409,
				'error' => $validator->errors(),
			];
			return response($resp);
		} else {
			$data = $request->all();
			// echo "<pre>"; print_r($data);
			
			if(isset($data['userId']) && isset($data['date'])){

				$fromDate = $data['date'];
				$toDate   = $data['date'];

				$screenshots = DB::table('screenshots')
								->where('user_id', $data['userId'])
								->whereBetween('created_at', [$fromDate." 00:00:00", $toDate." 23:59:59"])
								->get();
			} else if(isset($data['userId'])){
				$screenshots = DB::table('screenshots')->where(['id'=>$data['userId']])->get();	
			} else if(isset($data['date'])) {

				$fromDate = $data['date'];
				$toDate   = $data['date'];

				$screenshots = DB::table('screenshots')->whereBetween('created_at', [$fromDate." 00:00:00", $toDate." 23:59:59"])->get();
			} else {
				$screenshots = DB::table('screenshots')->get();
			}

			if ($screenshots->count()) {
				return response()->json($data = [
					'status' => 200,
					'msg' => 'Success',
					'data' => $screenshots
				]);
			} else {
				return response()->json($data = [
					'status' => 201,
					'msg' => 'Data Not Found'
				]);
			}

			// die;
		}
	}
}
