<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon; 
use App\User;
use DB;
use App\Project;
use App\Task;

class AdminController extends Controller
{
    public function adminDashboard()
    {
    	$current_date = Carbon::now()->format('Y-m-d');

        $startTimeUser = DB::table('times')
        // ->join('project_assignments', 'times.user_id', '=', 'project_assignments.user_id')
        ->whereBetween('times.start_time', [$current_date.' 00:00:00',$current_date.' 23:59:59'])->get();
        // echo "<pre>"; print_r($startTimeUser); die;

        $projectAssign = array();
        foreach($startTimeUser as $assign)
        {
            $data = DB::table('project_assignments')->where(['user_id' =>$assign->user_id])->first();
            if($data)
            {
                $projectAssign[] = $data;
            }
        }
        // echo "<pre>"; print_r($projectAssign); die;

        $users = array();
        foreach($projectAssign as $kk)
        {
            // echo $kk->user_id;
            $users[] = DB::table('users')
                ->where(['role' => 'USER', 'users.id' => $kk->user_id])
                ->join('project_assignments', 'users.id', '=', 'project_assignments.user_id')
                ->join('project_creations', 'project_assignments.task_id', '=', 'project_creations.id')
                ->join('times', 'users.id', '=', 'times.user_id')
                ->select('users.id as userid', 'users.name', 'users.email', 'times.start_time', 'times.duration', 'times.end_time', 'project_assignments.project_id', 'project_assignments.task_id', 'project_creations.working_per_hours')
                ->first();
                // echo "<pre>"; print_r($startTimeUser); die;
        }
        // die;
    	// echo "<pre>"; print_r($users); die;



    	return view('admin.admin_dashboard', compact('users'));
    }

    public function userEvent($user_id)
    {
    	$events = DB::table('keyboard_mouse_event_details')->where(['user_id' => $user_id])->get();
    	// echo "<pre>"; print_r($events); die;
    	return view('admin.user_events', compact('events'));
    }

    public function projectCreation()
    {
        $projects = Project::all();
        $projectCreations = DB::table('project_creations')
            ->join('projects', 'project_creations.project_id', '=', 'projects.id')
            ->select('project_creations.*', 'project_creations.id as project_id', 'projects.*')
            ->get();
        return view('admin.project_creation', compact('projects', 'projectCreations'));
    }

    public function saveProjectCreation(Request $request)
    {
        $saveProject = DB::table('project_creations')->insert([
            'project_id' => $request->project,
            'task' => $request->task,
            'working_per_hours' => $request->working_per_hours,
        ]);
        if($saveProject)
        {
            return back()->with('status', 'Saved successfully!');
        }
        else
        {
            return back()->with('status', 'Not saved');
        }
    }

    public function projectAssignment()
    {
        $projects = Project::all();
        $tasks = Task::all();
        $users = User::where(['role' => 'USER'])->get();
        $projectAssignments = DB::table('project_assignments')
            ->join('projects', 'project_assignments.project_id', '=', 'projects.id')
            ->join('project_creations', 'project_assignments.task_id', '=', 'project_creations.id')
            ->join('users', 'project_assignments.user_id', '=', 'users.id')
            ->select('users.*', 'projects.*', 'project_creations.*', 'project_assignments.id as project_id')
            ->get();
        return view('admin.project_assignment', compact('projects', 'tasks', 'users', 'projectAssignments'));
    }

    public function saveProjectAssignment(Request $request)
    {
        $messages = [
                'task_id.unique' => 'This task already assigned'
            ];

        $validator = Validator::make($request->all(), [
            'project' => 'required',
            'task_id' => 'required|unique:project_assignments',
            'user_id' => 'required',
        ], $messages);

        if ($validator->fails()) {
            return back()
                        ->withErrors($validator)
                        ->withInput();
        }
        $projectAssignments = DB::table('project_assignments')->get();

        $saveProject = DB::table('project_assignments')->insert([
            'project_id' => $request->project,
            'task_id' => $request->task_id,
            'user_id' => $request->user_id,
        ]);
        if($saveProject)
        {
            return back()->with('status', 'Saved successfully!');
        }
        else
        {
            return back()->with('status', 'Not saved');
        }
    }
}
