<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Auth;
use DB;
use App\User;

class AuthController extends Controller
{
    public function postLogin(Request $request)
    {
       
        $validator = Validator::make($request->all(), [
            'email' => 'required|email|max:255',
            'password' => 'required',
        ]);

        if ($validator->fails()) {
            return back()
                        ->withErrors($validator)
                        ->withInput();
        }

        $data = $request->all();
        // echo "<pre>"; print_r($data); die;

        $credentials = $request->only('email', 'password', 'role');
        // $credentials = $request->only('email', 'password');

        if (Auth::attempt($credentials)) {
            // Authentication passed...
            if(Auth::check() && Auth::user()->role=='ADMIN')
            {
                // echo Auth::user()->name;die;
                return redirect()->intended('/admin-dashboard');
            }
            else if(Auth::check() && Auth::user()->role=='USER')
            {
                return redirect('/home');
            }
            else
            {
                Auth::logout();
            	return back()->with('fail', 'Invalid Credentials');

            }
        }
        else
        {
            return back()->with('fail', 'Invalid Username or Password');
        }
    }
}
