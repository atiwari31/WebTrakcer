<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;
use DB;
use Auth;

class UserController extends Controller
{
    public function saveUserProjectTask(Request $request)
    {
        $messages = [
                'task_id.unique' => 'Already selected this task'
            ];

        $validator = Validator::make($request->all(), [
            'task_id' => 'required|unique:user_project_task',
        ], $messages);

        if ($validator->fails()) {
            return back()
                        ->withErrors($validator)
                        ->withInput();
        }

    	$start = Carbon::now();
        $saveProject = DB::table('user_project_task')->insert([
            'user_id' => Auth::id(),
            'project_id' => $request->project,
            'task_id' => $request->task_id,
            'start_time' => $start,
        ]);
        if($saveProject)
        {
            return back()->with('status', 'Saved successfully!');
        }
        else
        {
            return back()->with('status', 'Not saved');
        }
    }

    public function saveScreenshot(Request $request)
    {
        // return response($request);
        $image = $_POST['image'];

        $location = "upload/";

        $image_parts = explode(";base64,", $image);

        $image_base64 = base64_decode($image_parts[1]);

        // $filename = "screenshot_".uniqid().'.png';
        $filename = Auth::user()->name.'_'.time().'.png';

        $file = $location . $filename;

        file_put_contents($file, $image_base64);

        DB::table('screenshots')->insert([
            "image" => $filename,
            "image_path" => public_path().'/'.$file,
            "user_id" => Auth::id()
        ]);
    }
}
