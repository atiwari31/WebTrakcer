<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class time extends Model
{
    protected $fillable = [
        'user_id', 'start_time', 'duration', 'end_time'
    ];
}
