<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::post('/postLogin', 'AuthController@postLogin');

Route::group(['middleware' => ['is_admin']], function(){

	Route::get('/admin-dashboard', 'AdminController@adminDashboard');
	Route::get('/user-event/{user_id}', 'AdminController@userEvent');
	Route::get('/project-creation', 'AdminController@projectCreation');
	Route::post('/save-project-creation', 'AdminController@saveProjectCreation');
	Route::get('/project-assignment', 'AdminController@projectAssignment');
	Route::post('/save-project-assignment', 'AdminController@saveProjectAssignment');

});


Route::get('/time', 'TimeController@time');
Route::get('/project', 'TimeController@projectTask');
Route::get('/project2', 'TimeController@projectTask2');
Route::post('/saveScreenshot', 'UserController@saveScreenshot');
Route::post('/save-user-project-task', 'UserController@saveUserProjectTask');
Route::get('/getTask/{project_id}', 'TimeController@getTask');
Route::get('/save-start-time', 'TimeController@saveStartTime');
Route::get('/save-end-time', 'TimeController@saveEndTime');
Route::get('/keyboard', 'KeyboardMouseEventController@keyboard');
Route::get('/get-keyboard-details', 'KeyboardMouseEventController@getKeyboardDetails');
Route::post('/saveKeyboardDetail', 'KeyboardMouseEventController@saveKeyboardDetail');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
