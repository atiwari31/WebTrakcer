<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::get('/user-login', 'Api\ApiController@authenticate');
Route::get('/users', 'Api\ApiController@users');
Route::get('/projects', 'Api\ApiController@projects');
Route::post('/add-projects', 'Api\ApiController@addProject');
Route::post('/project-creation', 'Api\ApiController@projectCreation');
Route::get('/project-creation-list', 'Api\ApiController@projectCreationList');
Route::post('/project-assignment', 'Api\ApiController@projectAssignment');
Route::get('/project-assignment-list', 'Api\ApiController@projectAssignmentList');
Route::get('/user-timing-report', 'Api\ApiController@userTimingReport');
Route::get('/keyboard-mouse-event-details', 'Api\ApiController@keyboardMouseEventDetails');
Route::get('/user-project-task', 'Api\ApiController@userProjectTask');
Route::get('/screenshots', 'Api\ApiController@screenshots');
