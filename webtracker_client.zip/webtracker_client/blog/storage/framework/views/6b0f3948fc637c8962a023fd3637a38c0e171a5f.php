

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header" style="text-align: center;"><b>Project</b></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <form method="post" action="<?php echo e(url('save-user-project-task')); ?>"><?php echo csrf_field(); ?>
                        <div class="form-row">
                            <div class="form-group col-md-4">
                              <label for="inputEmail4"><b>Projects</b></label>
                              <select name="project" id="sel_project" class="form-control">
                                  <option disabled selected>Select Project</option>
                                  <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <option value="<?php echo e($p->id); ?>"><?php echo e($p->project); ?></option> 
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                            </div>
                            <div class="form-group col-md-4">
                              <label for="inputPassword4"><b>Task</b></label>
                              <select name="task" id="sel_task" class="form-control">
                              <option disabled selected>Select Task</option>
                              </select>
                            </div>

                            <div class="form-group col-md-4">
                              <button type="submit" class="btn btn-primary form-control" style="margin-top: 27px;">Start Task</button>
                            </div>

                        </div>
                        
                        <!-- <button type="submit" class="btn btn-primary">Start Task</button> -->
                    </form>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_js'); ?>
<!-- Script -->
<script type='text/javascript'>

$(document).ready(function(){

  // Project Change
  $('#sel_project').change(function(){

     // Project id
     var id = $(this).val();

    // alert('hi' + id);

     // Empty the dropdown
    //  $('#sel_task').find('option').not(':first').remove();
     $('#sel_task').find('option').remove();

     // AJAX request 
     $.ajax({
       url: 'getTask/'+id,
       type: 'get',
       dataType: 'json',
       success: function(response){

         var len = 0;
         if(response['data'] != null){
           len = response['data'].length;
         }

         if(len > 0){
           // Read data and create <option >
           for(var i=0; i<len; i++){

             var id = response['data'][i].id;
             var task = response['data'][i].task;

             var option = "<option value='"+id+"'>"+task+"</option>"; 

             $("#sel_task").append(option); 
           }
         }

       }
    });
  });

});

</script>

<script>
  addEventListener("keydown", function(event) {
    if (event.keyCode == 97)
      //document.body.style.background = "violet";
      eventHandleFun(97,"a");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 65)
      //document.body.style.background = "violet";
      eventHandleFun(65,"A");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 98)
      //document.body.style.background = "violet";
      eventHandleFun(98,"b");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 66)
      //document.body.style.background = "violet";
      eventHandleFun(66,"B");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 99)
      //document.body.style.background = "violet";
      eventHandleFun(99,"c");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 67)
      //document.body.style.background = "violet";
      eventHandleFun(67,"C");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 100)
      //document.body.style.background = "violet";
      eventHandleFun(100,"d");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 68)
      //document.body.style.background = "violet";
      eventHandleFun(68,"D");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 101)
      //document.body.style.background = "violet";
      eventHandleFun(101,"e");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 69)
      //document.body.style.background = "violet";
      eventHandleFun(69,"E");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 102)
      //document.body.style.background = "violet";
      eventHandleFun(102,"f");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 70)
      //document.body.style.background = "violet";
      eventHandleFun(70,"F");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 103)
      //document.body.style.background = "violet";
      eventHandleFun(103,"g");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 71)
      //document.body.style.background = "violet";
      eventHandleFun(71,"G");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 104)
      //document.body.style.background = "violet";
      eventHandleFun(104,"h");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 72)
      //document.body.style.background = "violet";
      eventHandleFun(72,"H");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 105)
      //document.body.style.background = "violet";
      eventHandleFun(105,"i");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 73)
      //document.body.style.background = "violet";
      eventHandleFun(73,"I");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 106)
      //document.body.style.background = "violet";
      eventHandleFun(106,"j");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 74)
      //document.body.style.background = "violet";
      eventHandleFun(74,"J");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 107)
      //document.body.style.background = "violet";
      eventHandleFun(107,"k");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 75)
      //document.body.style.background = "violet";
      eventHandleFun(75,"K");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 108)
      //document.body.style.background = "violet";
      eventHandleFun(108,"l");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 76)
      //document.body.style.background = "violet";
      eventHandleFun(76,"L");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 109)
      //document.body.style.background = "violet";
      eventHandleFun(109,"m");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 77)
      //document.body.style.background = "violet";
      eventHandleFun(77,"M");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 110)
      //document.body.style.background = "violet";
      eventHandleFun(110,"n");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 78)
      //document.body.style.background = "violet";
      eventHandleFun(78,"N");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 111)
      //document.body.style.background = "violet";
      eventHandleFun(111,"o");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 79)
      //document.body.style.background = "violet";
      eventHandleFun(79,"O");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 112)
      //document.body.style.background = "violet";
      eventHandleFun(112,"p");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 80)
      //document.body.style.background = "violet";
      eventHandleFun(80,"P");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 113)
      //document.body.style.background = "violet";
      eventHandleFun(113,"q");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 81)
      //document.body.style.background = "violet";
      eventHandleFun(81,"Q");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 114)
      //document.body.style.background = "violet";
      eventHandleFun(114,"r");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 82)
      //document.body.style.background = "violet";
      eventHandleFun(82,"R");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 115)
      //document.body.style.background = "violet";
      eventHandleFun(115,"s");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 83)
      //document.body.style.background = "violet";
      eventHandleFun(83,"S");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 116)
      //document.body.style.background = "violet";
      eventHandleFun(116,"t");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 84)
      //document.body.style.background = "violet";
      eventHandleFun(84,"T");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 117)
      //document.body.style.background = "violet";
      eventHandleFun(117,"u");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 85)
      //document.body.style.background = "violet";
      eventHandleFun(85,"U");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 118)
      //document.body.style.background = "violet";
      eventHandleFun(118,"v");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 86)
      //document.body.style.background = "violet";
      eventHandleFun(86,"V");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 119)
      //document.body.style.background = "violet";
      eventHandleFun(119,"w");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 87)
      //document.body.style.background = "violet";
      eventHandleFun(87,"W");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 120)
      //document.body.style.background = "violet";
      eventHandleFun(120,"x");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 88)
      //document.body.style.background = "violet";
      eventHandleFun(88,"X");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 121)
      //document.body.style.background = "violet";
      eventHandleFun(121,"y");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 89)
      //document.body.style.background = "violet";
      eventHandleFun(89,"Y");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 122)
      //document.body.style.background = "violet";
      eventHandleFun(122,"z");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 90)
      //document.body.style.background = "violet";
      eventHandleFun(90,"Z");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 48)
      //document.body.style.background = "violet";
      eventHandleFun(48,"0");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 49)
      //document.body.style.background = "violet";
      eventHandleFun(49,"1");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 50)
      //document.body.style.background = "violet";
      eventHandleFun(50,"2");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 51)
      //document.body.style.background = "violet";
      eventHandleFun(51,"3");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 52)
      //document.body.style.background = "violet";
      eventHandleFun(52,"4");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 53)
      //document.body.style.background = "violet";
      eventHandleFun(53,"5");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 54)
      //document.body.style.background = "violet";
      eventHandleFun(54,"6");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 55)
      //document.body.style.background = "violet";
      eventHandleFun(55,"7");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 56)
      //document.body.style.background = "violet";
      eventHandleFun(56,"8");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 57)
      //document.body.style.background = "violet";
      eventHandleFun(57,"9");
  });

  addEventListener("keydown", function(event) {
    if (event.keyCode == 32)
      //document.body.style.background = "violet";
      eventHandleFun(32,"Space");
  });
  addEventListener("keydown", function(event) {
    if (event.keyCode == 8)
      //document.body.style.background = "green";
      eventHandleFun(8,"Backpace");
  });
    addEventListener("keydown", function(event) {
    if (event.keyCode == 13)
      //document.body.style.background = "green";
      eventHandleFun(13,"Enter");
  });
  addEventListener("keydown", function(event) {
    if (event.keyCode == 16)
      //document.body.style.background = "green";
      eventHandleFun(16,"Shift");
  });
  addEventListener("keydown", function(event) {
    if (event.keyCode == 17)
      //document.body.style.background = "green";
      eventHandleFun(17,"Ctrl");
  });
  addEventListener("keydown", function(event) {
    if (event.keyCode == 18)
      //document.body.style.background = "green";
      eventHandleFun(18,"Alt");
  });
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>


<script>

  function eventHandleFun(keyCode,description){
// alert("hi");
    var dataString = 'keyCode='+keyCode+'&description='+description;
       
  $.ajax({
    type:"POST",
    //data:dataString,
   // _token:"<?php echo e(csrf_token()); ?>",
    data: { "_token": "<?php echo e(csrf_token()); ?>", "keyCode": keyCode,"description":description},
    url:'/saveKeyboardDetail',
    success:function(data) {
      // alert(data);
    }
  });

  
  

  }

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arvind verma\Desktop\indore\project\blog\resources\views/project_task.blade.php ENDPATH**/ ?>