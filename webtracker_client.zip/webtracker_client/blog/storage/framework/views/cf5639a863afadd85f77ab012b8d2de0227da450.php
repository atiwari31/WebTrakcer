

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header" style="text-align: center;"><b>Project Creation</b></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <form method="post" action="<?php echo e(url('/save-project-creation')); ?>"><?php echo csrf_field(); ?>
                        <div class="form-row">
                            <div class="form-group col-md-4">
                            <label for="inputEmail4"><b>Projects</b></label>
                            <select name="project" id="sel_project" class="form-control">
                                <option disabled selected>Select Project</option>
                                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <option value="<?php echo e($p->id); ?>"><?php echo e($p->project); ?></option> 
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            </div>
                            <div class="form-group col-md-4">
                            <label for="inputPassword4"><b>Task</b></label>
                            <input type="text" name="task" class="form-control">
                            </div>
                            <div class="form-group col-md-4">
                            <label for="inputPassword4"><b>Working per hours</b></label>
                            <input type="text" name="working_per_hours" class="form-control">
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-12">
            <div class="card">
                <div class="card-header" style="text-align: center;"><b>Project Creation Details</b></div>

                <div class="card-body">
                    
                    <table class="table">
                        <thead>
                            <tr>
                            <th scope="col">id</th>
                            <th scope="col">Project</th>
                            <th scope="col">Task</th>
                            <th scope="col">Working per hours</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $projectCreations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projectCreation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                            <th scope="row"><?php echo e($projectCreation->id); ?></th>
                            <td><?php echo e($projectCreation->project); ?></td>
                            <td><?php echo e($projectCreation->task); ?></td>
                            <td><?php echo e($projectCreation->working_per_hours); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\indore\project\blog\resources\views/admin/project_creation.blade.php ENDPATH**/ ?>