<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <!-- for screenshot -->
    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> -->
    <?php echo $__env->yieldContent('page_css'); ?>
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <!-- <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <?php echo e(config('app.name', 'Home')); ?>

                </a> -->
                <?php if(Auth::check() && Auth::user()->role == 'ADMIN'): ?>
                <a class="navbar-brand" href="<?php echo e(url('/project-creation')); ?>" style="font-size: 14px;">
                    <b>Project Creation</b>
                </a>
                <a class="navbar-brand" href="<?php echo e(url('/project-assignment')); ?>" style="font-size: 14px;">
                    <b>Project Assignment</b>
                </a>
                <a class="navbar-brand" href="<?php echo e(url('/admin-dashboard')); ?>" style="font-size: 14px;">
                    <b>User Timing Report</b>
                </a>
                <?php elseif(Auth::check() && Auth::user()->role == 'USER'): ?>
                <a class="navbar-brand" href="<?php echo e(url('save-start-time')); ?>" style="font-size: 14px;">
                    <b>Start Time</b>
                        
                </a>
                <a class="navbar-brand" href="<?php echo e(url('save-end-time')); ?>" style="font-size: 14px;">
                    <b>End Time</b>
                </a>

                <button id="cake" >Take Screeny</button>

                <canvas id="fake" style="display:none;"></canvas>
                <?php endif; ?>
                

                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                            </li>
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?>

                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <script type="text/javascript">

         // setInterval(function(){
    
         //  takeScreenShot();
         //   }, 6000);


  const canIRun  = navigator.mediaDevices.getDisplayMedia ;
 
     
    const takeScreenShot = async () => {

 const stream = await navigator.mediaDevices.getDisplayMedia({
          
             video: {mediaSource: 'monitor',video:false,cursor: "always"
                    },
          })

          // get correct video track
          const track = stream.getVideoTracks()[0]
          // init Image Capture and not Video stream
          const imageCapture = new ImageCapture(track)
          // take first frame only
          const bitmap = await imageCapture.grabFrame()
          // destory video track to prevent more recording / mem leak
          track.stop()

           const canvas = document.getElementById('fake') 
          // this could be a document.createElement('canvas') if you want
          // draw weird image type to canvas so we can get a useful image
          canvas.width = bitmap.width
          canvas.height = bitmap.height
          const context = canvas.getContext('2d')
          context.drawImage(bitmap, 0, 0, bitmap.width, bitmap.height)
       
          var base64URL = canvas.toDataURL('image/jpeg').replace('image/jpeg', 'image/octet-stream');

       $.ajax({
                    url: '/saveScreenshot',
                    type: 'post',
                    data: {"_token": "<?php echo e(csrf_token()); ?>", image: base64URL},
                    success: function(data){
                       console.log('Upload successfully');
                       console.log(data);
                    }
                 });

     } 

    const button = document.getElementById('cake').onclick = () => canIRun ? takeScreenShot() : {}


    </script>

      <?php echo $__env->yieldContent('page_js'); ?>
    

</body>
</html>

<script type="text/javascript"></script>>
<?php /**PATH D:\WebTracker\project\blog\resources\views/layouts/app.blade.php ENDPATH**/ ?>