

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header" style="text-align: center;"><b>Project Assignment</b></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <form method="post" action="<?php echo e(url('/save-project-assignment')); ?>"><?php echo csrf_field(); ?>
                        <div class="form-row">
                            <div class="form-group col-md-4">
                            <label for="inputEmail4"><b>Projects</b></label>
                            <select name="project" id="sel_project" class="form-control">
                                <option disabled selected>Select Project</option>
                                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <option value="<?php echo e($p->id); ?>"><?php echo e($p->project); ?></option> 
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                             <?php $__errorArgs = ['project'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                            </div>
                            <div class="form-group col-md-4">
                            <label for="inputPassword4"><b>Task</b></label>
                            <select name="task_id" id="sel_task" class="form-control">
                            <option disabled selected>Select Task</option>
                            
                            </select>
                             <?php $__errorArgs = ['task_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group col-md-4">
                            <label for="inputPassword4"><b>User</b></label>
                            <select name="user_id" id="sel_project" class="form-control">
                                <option disabled selected>Select User</option>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option> 
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                             <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Assign</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-12">
            <div class="card">
                <div class="card-header" style="text-align: center;"><b>Project Assignment Details</b></div>

                <div class="card-body">
                    
                    <table class="table">
                        <thead>
                            <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Project</th>
                            <th scope="col">Task</th>
                            <th scope="col">User</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $projectAssignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projectAssignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                            <th scope="row"><?php echo e($projectAssignment->project_id); ?></th>
                            <td><?php echo e($projectAssignment->project); ?></td>
                            <td><?php echo e($projectAssignment->task); ?></td>
                            <td><?php echo e($projectAssignment->name); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_js'); ?>
<!-- Script -->
<script type='text/javascript'>

$(document).ready(function(){

  // Project Change
  $('#sel_project').change(function(){

     // Project id
     var id = $(this).val();

    // alert('hi' + id);

     // Empty the dropdown
    //  $('#sel_task').find('option').not(':first').remove();
     $('#sel_task').find('option').remove();

     // AJAX request 
     $.ajax({
       url: 'getTask/'+id,
       type: 'get',
       dataType: 'json',
       success: function(response){

        console.log(response);

         var len = 0;
         if(response['data'] != null){
           len = response['data'].length;
         }

         if(len > 0){
           // Read data and create <option >
           for(var i=0; i<len; i++){

             var id = response['data'][i].id;
             var task = response['data'][i].task;

             var option = "<option value='"+id+"'>"+task+"</option>"; 

             $("#sel_task").append(option); 
           }
         }

       }
    });
  });

});

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp\Downloads\Indore Project\webtracker_client\blog\resources\views/admin/project_assignment.blade.php ENDPATH**/ ?>